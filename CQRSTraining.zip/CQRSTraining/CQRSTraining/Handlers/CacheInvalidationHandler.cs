﻿using CQRSTraining.Entities;
using CQRSTraining.Notifications;
using MediatR;

namespace CQRSTraining.Handlers
{
    public class CacheInvalidationHandler : INotificationHandler<ProductAddedNotification>
    {
        private readonly DataStore _dataStore;
        public CacheInvalidationHandler(DataStore dataStore) => _dataStore = dataStore;
        public async Task Handle(ProductAddedNotification notification, CancellationToken cancellationToken)
        {
            await _dataStore.EventOccured(notification.Product, "Cache Invalidated");
            await Task.CompletedTask;
        }
    }
}
